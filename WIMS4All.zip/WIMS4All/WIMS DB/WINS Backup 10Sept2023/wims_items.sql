-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: wims
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `item_id` varchar(50) NOT NULL,
  `item_client` varchar(50) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `item_description` varchar(50) NOT NULL,
  `item_uom` varchar(50) NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES ('item1','client1','Widget','A small plastic widget used for various purposes','EA'),('item10','client2','Office Chair','An ergonomic office chair for comfort','EA'),('item11','client3','LED TV','A 55-inch LED TV with 4K resolution','EA'),('item12','client3','Coffee Maker','A programmable coffee maker for your morning brew','EA'),('item13','client3','Running Shoes','High-performance running shoes for athletes','EA'),('item14','client3','Digital Camera','A compact digital camera with advanced features','EA'),('item15','client3','Backpack','A durable backpack for outdoor adventures','EA'),('item16','client4','Wireless Mouse','A wireless mouse with standard ergonomic design','EA'),('item17','client4','Bluetooth Speaker','A portable Bluetooth speaker for music lovers','EA'),('item18','client4','Laptop Bag','A stylish and protective laptop bag','EA'),('item19','client4','HD Webcam','A high-definition webcam for video conferencing','EA'),('item2','client1','Gizmo','An electronic gizmo with multiple functions','BX'),('item20','client4','Smart Thermostat','A smart thermostat for home climate control','EA'),('item3','client1','Tool Kit','A toolkit containing essential tools','BNDL'),('item4','client1','Widget Pro','An advanced version of the widget','EA'),('item5','client1','Tech Gadgets','A bundle of the latest tech gadgets','BNDL'),('item6','client2','Smartphone','A high-end smartphone with cutting-edge features','EA'),('item7','client2','Laptop','A powerful laptop for work and entertainment','EA'),('item8','client2','Paperback Book','A bestselling novel in paperback format','EA'),('item9','client2','Bluetooth Speaker','A portable speaker with wireless connectivity','EA');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-10 20:16:26

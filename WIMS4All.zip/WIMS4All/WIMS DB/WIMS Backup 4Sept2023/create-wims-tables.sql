USE `wims`;

CREATE TABLE `users` (
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_client` varchar(50) NOT NULL,
  `user_role` varchar(50) NOT NULL,
  `user_phone` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `users` VALUES ('user1','Nancy K. Battaglia','password1','NancyKBattaglia@jourrapide.com','client1','user','404-523-7066');
INSERT INTO `users` VALUES ('user2','Steve C. Hensley','password2','SteveCHensley@dayrep.com','client2','user','309-820-6313');
INSERT INTO `users` VALUES ('user3','Ken R. Ferri','password3','KenRFerri@armyspy.com','client3','user','936-263-8532');
INSERT INTO `users` VALUES ('user4','Irma N. Mutter','password4','IrmaNMutter@teleworm.us','client4','user','267-808-2249');


CREATE TABLE `clients` (
  `client_id` varchar(50) NOT NULL,
  `client_name` varchar(50) NOT NULL,
  `client_address1` varchar(50) NOT NULL,
  `client_address2` varchar(50),
  `client_city` varchar(50) NOT NULL,
  `client_state` varchar(50) NOT NULL,
  `client_zip` varchar(50) NOT NULL,
  `client_phone` varchar(50) NOT NULL,
  `client_email` varchar(50) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `clients` VALUES ('client1','TechPro Solutions','1234 Elm Street, Suite 567','','Springfield','IL','62701','(555) 123-4567','info@techprosolutions.com');
INSERT INTO `clients` VALUES ('client2','Global Innovations Inc','789 Maple Avenue, Unit 101','','Seattle','WA','98101','(206) 555-7890','contact@globalinnovations.com');
INSERT INTO `clients` VALUES ('client3','TechSolutions Ltd.',' 123 Technology Park','','San Francisco','CA','94101','(415) 555-1234','info@techsolutions.com');
INSERT INTO `clients` VALUES ('client4','Global Logistics Inc.','789 Warehouse Way','','Dallas','TX','75201','(214) 555-5678','contact@globallogistics.com');


CREATE TABLE `items` (
  `item_id` varchar(50) NOT NULL,
  `item_client` varchar(50) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `item_description` varchar(50) NOT NULL,
  `item_uom` varchar(50) NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `items` VALUES ('item1','client1','Widget','A small plastic widget used for various purposes','EA');
INSERT INTO `items` VALUES ('item2','client1','Gizmo','An electronic gizmo with multiple functions','BX');
INSERT INTO `items` VALUES ('item3','client1','Tool Kit','A toolkit containing essential tools','BNDL');
INSERT INTO `items` VALUES ('item4','client1','Widget Pro','An advanced version of the widget','EA');
INSERT INTO `items` VALUES ('item5','client1','Tech Gadgets','A bundle of the latest tech gadgets','BNDL');
INSERT INTO `items` VALUES ('item6','client2','Smartphone','A high-end smartphone with cutting-edge features','EA');
INSERT INTO `items` VALUES ('item7','client2','Laptop','A powerful laptop for work and entertainment','EA');
INSERT INTO `items` VALUES ('item8','client2','Paperback Book','A bestselling novel in paperback format','EA');
INSERT INTO `items` VALUES ('item9','client2','Bluetooth Speaker','A portable speaker with wireless connectivity','EA');
INSERT INTO `items` VALUES ('item10','client2','Office Chair','An ergonomic office chair for comfort','EA');
INSERT INTO `items` VALUES ('item11','client3','LED TV','A 55-inch LED TV with 4K resolution','EA');
INSERT INTO `items` VALUES ('item12','client3','Coffee Maker','A programmable coffee maker for your morning brew','EA');
INSERT INTO `items` VALUES ('item13','client3','Running Shoes','High-performance running shoes for athletes','EA');
INSERT INTO `items` VALUES ('item14','client3','Digital Camera','A compact digital camera with advanced features','EA');
INSERT INTO `items` VALUES ('item15','client3','Backpack','A durable backpack for outdoor adventures','EA');
INSERT INTO `items` VALUES ('item16','client4','Wireless Mouse','A wireless mouse with ergonomic design','EA');
INSERT INTO `items` VALUES ('item17','client4','Bluetooth Speaker','A portable Bluetooth speaker for music lovers','EA');
INSERT INTO `items` VALUES ('item18','client4','Laptop Bag','A stylish and protective laptop bag','EA');
INSERT INTO `items` VALUES ('item19','client4','HD Webcam','A high-definition webcam for video conferencing','EA');
INSERT INTO `items` VALUES ('item20','client4','Smart Thermostat','A smart thermostat for home climate control','EA');


CREATE TABLE `addresses` (
  `address_id` varchar(50) NOT NULL,
  `address_client` varchar(50) NOT NULL,
  `address_name` varchar(50) NOT NULL,
  `address_line1` varchar(50) NOT NULL,
  `address_line2` varchar(50),
  `address_city` varchar(50) NOT NULL,
  `address_state` varchar(50) NOT NULL,
  `address_zip` varchar(50) NOT NULL,
  `address_phone` varchar(50) NOT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `addresses` VALUES ('address1','client1','John Smith','123 Main St','','Anytown','CA','12345','555-123-4567');
INSERT INTO `addresses` VALUES ('address2','client1','Jane Doe','456 Elm St','','Smallville','NY','67890','555-987-6543');
INSERT INTO `addresses` VALUES ('address3','client2','Robert Johnson','789 Oak St','','Big City','TX','54321','555-567-8901');
INSERT INTO `addresses` VALUES ('address4','client2','Lisa Anderson','101 Pine St','','Cozyville','WA','23456','555-234-5678');
INSERT INTO `addresses` VALUES ('address5','client3','Michael Brown','234 Maple St','','Metropolis','IL','87654','555-876-5432');
INSERT INTO `addresses` VALUES ('address6','client3','Susan Taylor','567 Birch St','','Sunnyville','FL','76543','555-345-6789');
INSERT INTO `addresses` VALUES ('address7','client4','David Wilson','890 Cedar St','','Ruraltown','GA','43210','555-210-9876');
INSERT INTO `addresses` VALUES ('address8','client4','Emily Davis','222 Spruce St','','Suburbia','OH','32109','555-789-0123');


CREATE TABLE `inventory` (
  `inventory_line` int NOT NULL AUTO_INCREMENT,
  `inventory_item` varchar(50) NOT NULL,
  `inventory_client` varchar(50) NOT NULL,
  `inventory_location` varchar(50) NOT NULL,
  `inventory_onhand` int NOT NULL,
  `inventory_reserved` int NOT NULL,
  `inventory_hold` int NOT NULL,
  PRIMARY KEY (`inventory_line`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item1','client1','A1A1','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item2','client1','A1A1','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item3','client1','A1A2','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item4','client1','A1A2','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item5','client1','A2B1','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item6','client2','A2A1','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item7','client2','B1A1','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item8','client2','B1B1','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item9','client2','B1A2','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item10','client2','A4A1','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item11','client3','A4A1','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item12','client3','B3B2','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item13','client3','A3A2','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item14','client3','D6A1','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item15','client3','A1A1','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item16','client4','D6B2','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item17','client4','C1A1','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item18','client4','A1E3','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item19','client4','F2B1','50','0','0');
INSERT INTO `inventory` (`inventory_item`,`inventory_client`,`inventory_location`,`inventory_onhand`,`inventory_reserved`,`inventory_hold`) VALUES ('item20','client4','G1C3','50','0','0');


CREATE TABLE `audits` (
  `audit_line` int NOT NULL AUTO_INCREMENT,
  `audit_item` varchar(50) NOT NULL,
  `audit_client` varchar(50) NOT NULL,
  `audit_start_date` varchar(50) NOT NULL,
  `audit_end_date` varchar(50) NOT NULL,
  `audit_type` varchar(50) NOT NULL,
  `audit_started_by` varchar(50) NOT NULL,
  `audit_action_by` varchar(50) NOT NULL,
  `audit_status` varchar(50) NOT NULL,
  PRIMARY KEY (`audit_line`));


CREATE TABLE `orderheader` (
  `orderhdr_id` varchar(50) NOT NULL,
  `orderhdr_client` varchar(50) NOT NULL,
  `orderhdr_dest_name` varchar(50) NOT NULL,
  `orderhdr_dest_addr1` varchar(50) NOT NULL,
  `orderhdr_dest_addr2` varchar(50),
  `orderhdr_dest_city` varchar(50) NOT NULL,
  `orderhdr_dest_state` varchar(50) NOT NULL,
  `orderhdr_dest_zip` varchar(50) NOT NULL,
  `orderhdr_total_items` int NOT NULL,
  `orderhdr_status` varchar(50) NOT NULL,
  PRIMARY KEY (`orderhdr_id`));


CREATE TABLE `orderdetail` (
  `orddetail_id` varchar(50) NOT NULL,
  `orddetail_item_name` varchar(50) NOT NULL,
  `orddetail_item_desc` varchar(50) NOT NULL,
  `orddetail_qty_ord` int NOT NULL,
  `orddetail_qty_conf` int NOT NULL,
  `orddetail_qty_shipped` int NOT NULL,
  `orddetail_item_uom` varchar(50) NOT NULL,
  PRIMARY KEY (`orddetail_id`));


CREATE TABLE `backordhdr` (
  `orderhdr_id` varchar(50) NOT NULL,
  `orderhdr_client` varchar(50) NOT NULL,
  `orderhdr_dest_name` varchar(50) NOT NULL,
  `orderhdr_dest_addr1` varchar(50) NOT NULL,
  `orderhdr_dest_addr2` varchar(50),
  `orderhdr_dest_city` varchar(50) NOT NULL,
  `orderhdr_dest_state` varchar(50) NOT NULL,
  `orderhdr_dest_zip` varchar(50) NOT NULL,
  `orderhdr_total_items` int NOT NULL,
  `orderhdr_status` varchar(50) NOT NULL,
  PRIMARY KEY (`orderhdr_id`));


CREATE TABLE `backorddetail` (
  `backorddetail_id` varchar(50) NOT NULL,
  `backorddetail_item_name` varchar(50) NOT NULL,
  `backorddetail_item_desc` varchar(50) NOT NULL,
  `backorddetail_qty_ord` int NOT NULL,
  `backorddetail_qty_conf` int NOT NULL,
  `backorddetail_qty_shipped` int NOT NULL,
  `backorddetail_item_uom` varchar(50) NOT NULL,
  PRIMARY KEY (`backorddetail_id`));


CREATE TABLE `ordhdrclosed` (
  `ordhdrclosed_id` varchar(50) NOT NULL,
  `ordhdrclosed_client` varchar(50) NOT NULL,
  `ordhdrclosed_dest_name` varchar(50) NOT NULL,
  `ordhdrclosed_dest_addr1` varchar(50) NOT NULL,
  `ordhdrclosed_dest_addr2` varchar(50),
  `ordhdrclosed_dest_city` varchar(50) NOT NULL,
  `ordhdrclosed_dest_state` varchar(50) NOT NULL,
  `ordhdrclosed_dest_zip` varchar(50) NOT NULL,
  `ordhdrclosed_total_items` int NOT NULL,
  `ordhdrclosed_status` varchar(50) NOT NULL,
  PRIMARY KEY (`ordhdrclosed_id`));


CREATE TABLE `orddetailclosed` (
  `orddetailclosed_id` varchar(50) NOT NULL,
  `orddetailclosed_item_name` varchar(50) NOT NULL,
  `orddetailclosed_item_desc` varchar(50) NOT NULL,
  `orddetailclosed_qty_ord` int NOT NULL,
  `orddetailclosed_qty_conf` int NOT NULL,
  `orddetailclosed_qty_shipped` int NOT NULL,
  `orddetailclosed_item_uom` varchar(50) NOT NULL,
  PRIMARY KEY (`orddetailclosed_id`));
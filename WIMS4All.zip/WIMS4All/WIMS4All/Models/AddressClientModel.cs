﻿namespace WIMS3.Models
{
    public class AddressClientModel
    {
        public string address_id { get; set; }
        public string address_client { get; set; }
        public string address_name { get; set;} 
        public string address_line1 { get; set;}
        public string address_line2{ get; set; }
        public string address_city { get; set; }
        public string address_state { get; set; }
        public string address_zip { get; set; }
        public string address_phone { get; set; }
    }
}

﻿namespace WIMS3.Models
{
    public class OrderDetailsModel
    {
        public string orddetail_id { get; set; }
        public string orddetail_item_name { get; set; }
        public string orddetail_item_desc { get; set;} 
        public int orddetail_qty_ord { get; set;}
        public int orddetail_qty_conf { get; set; }
        public int orddetail_qty_shipped { get; set; }
        public string orddetail_item_uom { get; set; }

    }
}

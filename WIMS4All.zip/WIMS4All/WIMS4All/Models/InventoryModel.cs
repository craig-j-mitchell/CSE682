﻿namespace WIMS3.Models
{
    public class InventoryModel
    {
        public string inventory_item { get; set; }
        public string inventory_client { get; set; }
        public string inventory_location { get; set;} 
        public int inventory_onhand { get; set;}
        public int inventory_reserved { get; set; }
        public int inventory_hold { get; set; }

    }
}

﻿namespace WIMS3.Models
{
    public class OrderHdrModels
    {
        public string orderhdr_id { get; set; }
        public string orderhdr_client { get; set; }
        public string orderhdr_dest_name { get; set; }
        public string orderhdr_dest_addr1 { get; set; }
        public string orderhdr_dest_addr2 { get; set; }
        public string orderhdr_dest_city { get; set; }
        public string orderhdr_dest_state { get; set; }
        public string orderhdr_dest_zip { get; set; }
        public int orderhdr_total_items { get; set; }
        public string orderhdr_status { get; set; }
    }
}

﻿namespace WIMS3.Models
{
    public class ItemsModel
    {
        public string item_id { get; set; }
        public string item_client { get; set; }
        public string item_name { get; set;} 
        public string item_description { get; set;}
        public string item_uom { get; set; }

    }
}

﻿namespace WIMS3.Models
{
    public class UserModel
    {
        public string user_id { get; set; }
        public string user_name { get; set; }
        public string user_email { get; set; }
        public string user_client { get; set; }
        public string user_role { get; set; }
        public string user_phone { get; set; }

    }
}

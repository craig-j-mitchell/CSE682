-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: wims
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aspnetusers`
--

DROP TABLE IF EXISTS `aspnetusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aspnetusers` (
  `Id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `UserName` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `NormalizedUserName` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Email` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `NormalizedEmail` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `EmailConfirmed` tinyint(1) NOT NULL,
  `PasswordHash` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `SecurityStamp` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `ConcurrencyStamp` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `PhoneNumber` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `PhoneNumberConfirmed` tinyint(1) NOT NULL,
  `TwoFactorEnabled` tinyint(1) NOT NULL,
  `LockoutEnd` datetime(6) DEFAULT NULL,
  `LockoutEnabled` tinyint(1) NOT NULL,
  `AccessFailedCount` int NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UserNameIndex` (`NormalizedUserName`),
  KEY `EmailIndex` (`NormalizedEmail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aspnetusers`
--

LOCK TABLES `aspnetusers` WRITE;
/*!40000 ALTER TABLE `aspnetusers` DISABLE KEYS */;
INSERT INTO `aspnetusers` VALUES ('4cd6f38a-5b23-47d6-b2b9-b48109229fcc','test@test.com','TEST@TEST.COM','test@test.com','TEST@TEST.COM',1,'AQAAAAIAAYagAAAAEF1Hw3rbUiBB9Ymshqu/5uTVBl8Yvd3ouqhVq2rVAvfQhpw+FcVXxccA2AluuKRowg==','VCNX3CM5TLWV5CADIJ5TOXBGMDBQ3IVV','4ac34966-e7c2-4afa-a315-0ee06c7ce48a',NULL,0,0,NULL,1,0),('8bcb502e-f6a7-4ef9-8a67-3ee49c25291e','whsuser@wims4all.com','WHSUSER@WIMS4ALL.COM','whsuser@wims4all.com','WHSUSER@WIMS4ALL.COM',0,'AQAAAAIAAYagAAAAEFxrJYgWI6tSS1M/w6WRqxejnWIUYes8w8+91azeIJ5p9UHM0d2WXSJRR1O593vo/Q==','YZQGWX2GADODDFVBM4DJ73NS3WB7C2WK','8b67004a-ecbb-488e-a1b0-3ae51d214e04',NULL,0,0,NULL,1,0),('99982a02-59e8-42a9-9fa7-83be57040cad','client@client.com','CLIENT@CLIENT.COM','client@client.com','CLIENT@CLIENT.COM',1,'AQAAAAIAAYagAAAAEL5Dqsu/AID7vB0xInSx0Kw7exdn6UEOywBd0H8ylbIACCL3LcR013/utld7Qh8w+g==','PIAIB6L25JRGRDEFW6EBMMQNEVZW5X5I','8da6c74e-9e99-43e0-be3d-cd5e735afcd7',NULL,0,0,NULL,1,0),('db337570-ea57-4b50-96eb-dc3d325579b5','user@wims4all.com','USER@WIMS4ALL.COM','user@wims4all.com','USER@WIMS4ALL.COM',1,'AQAAAAIAAYagAAAAEPX9etMIXsywtxJdVimk3UsM06FUuur7W540GWhkzFwbNU+51peMfv9lZE2hxGdL/A==','LUKI7V42L6UKWZVL2TYO7KZHG566LKUH','99a99d50-89a6-473b-846e-ad876d49326d',NULL,0,0,NULL,1,0),('fbdce148-143a-44df-920a-888346491d32','admin@wims4all.com','ADMIN@WIMS4ALL.COM','admin@wims4all.com','ADMIN@WIMS4ALL.COM',1,'AQAAAAIAAYagAAAAELAGXrpEaH3ON4YYD1rvje1pIENhk+iDOcyn00yFijyKKocHUCrDv30onDGm4Yiutw==','3KLWRBH4OZG5ASXTG5JXJIT5MVSYT6A7','a8d17502-d429-4a34-a0b6-13031c8a0a4b',NULL,0,0,NULL,1,0);
/*!40000 ALTER TABLE `aspnetusers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-10 20:16:25

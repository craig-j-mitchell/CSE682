﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMS1.Models
{
    public class UserModel
    {
        public string user_id { get; set; }
        public string user_name { get; set; }
        public string password { get; set; }
     
    }
}
